#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <time.h> 
#include <pthread.h> 
#include <sys/time.h>

#define TIME_OUT 10



int j=0;
int s=0;
long array [100000];

//calculates the average latency for TCP connections

void TCP_Latency()
{
    int i;
    while(1)
      {
           if (j==9999 )
              {
                 for (i = 0; i < 10000; i++) 
                     {
                       printf("Thread %d  \n",i+1);
                     }
                 break;
              } 
      } 

    long sum=0;
    float average_counting;
    long k;

    FILE *fp;
    fp=fopen("latency_per_conncections_tcp.txt","w"); 
    
    for (k = 0; k < 10000; k++) 
      
      {
       
        sum= sum + array [k];

        if ((k+1)%1000==0 )
             
             { 
                   average_counting = (sum/k+1); // Calculates average latency for a number of TCP connections
        
        printf("The average latency for %li connections is %f miliseconds \n",k+1,average_counting);
        fprintf(fp,"%li %f \n",k+1,average_counting); // Writing the valueof number of connections and average latency in a text file
        
             
             }
        
      }
}

//calculates the average latency for UDP connections

void UDP_Latency()
{

      int i;

      while(1)
       
       {
            if (j== 999 )
               {
                   for (i = 0; i < 1000; i++) 
                     {
                         printf("Thread %d  \n",i+1);
                         
                     }
 
                   break;
               } 
       } 

      long sum=0;
      float average_counting;
      long k;

      FILE *fp;
      fp=fopen("latency_per_conncections_udp.txt","w"); 
      
      for (k = 0; k < 1000; k++) 
      
       {
       
         sum= sum + array [k];

         if ((k+1)% 100 == 0 )
             
             { 
                   average_counting = (sum/k+1); // Calculates average latency for a number of UDP connections
        
                   printf("The average latency for %li connections is %f miliseconds \n",k+1,average_counting);
                    
                   fprintf(fp,"%li %f \n",k+1,average_counting); // Writing the value of number of connections and average latency in a text file
                   
             
             }

        
       }

                   
    
    

       

}
void *creating_thread_tcp(void *vargp) 
{ 
        char protocal[4] ="TCP";
        char URL[]="www.cs585.com";
        printf("The protocal is: %s\n",protocal);
        printf("The URL is: %s\n", URL);
	char *address;
        address="127.0.0.1";//this IP address need to be changed according to the network

	//create the socket for client
	int client_socket;
	
        if( strcmp(protocal,"TCP")==0 )
          {
		client_socket=socket(AF_INET, SOCK_STREAM, 0);
	  }
        if( strcmp(protocal,"TCP")!=0 )
          {
		client_socket=socket(AF_INET, SOCK_DGRAM, 0);

	  }
	

	if(strcmp(protocal,"TCP")==0)
          {
		//connect to an address, not the usual 80 port for HTTP
		struct sockaddr_in remote_address;
		memset(&remote_address, 0, sizeof(remote_address));
		remote_address.sin_family = AF_INET;
		remote_address.sin_port = htons(8080);
		//inet_aton(address, &remote_address.sin_addr.s_addr);//convert the IP address to net order HEX address
		inet_pton(AF_INET, address, &remote_address.sin_addr.s_addr);

		int connect_result;
		printf("%s\n","begin to make pconnection");
		connect_result=connect(client_socket, (struct sockaddr *) &remote_address, sizeof(remote_address) );

		if(connect_result==0)
                {
			printf("connection to %s established\n",address);
		}
                else
                {
			printf("connection to %s faliure\n",address);
			
		}


                //Calculating time while sending request
                struct timeval te1; 
                gettimeofday(&te1, NULL); // get current time
                long  tt1 = te1.tv_sec*1000LL + te1.tv_usec/1000; // calculate milliseconds
                printf("\n Sending time : %li for thread %d \n",tt1,j);
           
       

		//send the GET request to the web server
		char request[] = "GET /lab2.html HTTP/1.0\r\nHOST:cs585.org\r\n\r\n";
		write(client_socket,request,strlen(request));
		
		//respond from the server
		char response[4096];
                read(client_socket,response,4096);
                printf("%s",response);
                          
                 //Calculating time while receiving response
                struct timeval te; 
                gettimeofday(&te, NULL); // get current time
                long  tt = te.tv_sec*1000LL + te.tv_usec/1000; // calculate milliseconds
                printf("\n Receiving time : %li for thread %d \n",tt,j);
 
                 //Calculating the time difference between request and response
                printf("\n *******The time difference is************* %li for thread %d \n",(tt-tt1),j++); 
                array [j]=tt-tt1;
            
		close(client_socket);
            
	 }
 



} 

void *creating_thread_udp(void *vargp) 
{ 
              
        char protocal[4] ="UDP";
        char URL[]="www.cs585.com";
        printf("The protocal is: %s\n",protocal);
        printf("The URL is: %s\n", URL);
		



        
	//connect to the address of the web Server
	char *address;
       
	address="127.0.0.1";//this IP address need to be changed according to the network

	
	

	

	if(strcmp(protocal,"UDP")==0)
          {
	    
              
	 
           
          
            printf("UDP part\n");

            int sockfd; 
	    char buffer[1024]; 
	    char *hello = "Hello from client"; 
	    struct sockaddr_in     servaddr; 
	    char *address;
	    address="127.0.0.1"; //this IP address need to be changed according to the network
	  
	    // Creating socket file descriptor 
	    if ( (sockfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0 ) 
            { 
	        perror("socket creation failed"); 
	        exit(EXIT_FAILURE); 
	    } 
	  
	    memset(&servaddr, 0, sizeof(servaddr)); 
	      
	    // Filling server information 
	    servaddr.sin_family = AF_INET; 
	    servaddr.sin_port = htons(8080); 
	    
	    inet_pton(AF_INET, address, &servaddr.sin_addr.s_addr);
	      
	    int n, len; 
            
            //Calculating time while sending request
            struct timeval te1; 
            gettimeofday(&te1, NULL); // get current time
            long  tt1 = te1.tv_sec*1000LL + te1.tv_usec/1000; // calculate milliseconds
            printf("\n Sending time : %li for thread %d \n",tt1,j);
	        if(s==0)
                   {
 
                      s++;
                      sendto(sockfd, (const char *)hello, strlen(hello), 
	              MSG_CONFIRM, (const struct sockaddr *) &servaddr, sizeof(servaddr)); 
	              printf("Trying to make connection with server.\n"); 
            

                   }

               else
                   {
	    sendto(sockfd, (const char *)hello, strlen(hello), 
	    MSG_CONFIRM, (const struct sockaddr *) &servaddr, sizeof(servaddr)); 
	    printf("Trying to make connection with server.\n"); 

     

            n = recvfrom(sockfd, (char *)buffer, 1024,  
	    MSG_WAITALL, (struct sockaddr *) &servaddr, &len); 
	    buffer[n] = '\0'; 
	    printf("Server response: %s\n", buffer); 
	  
	   



               

             //Calculating time while receiving response
            struct timeval te; 
            gettimeofday(&te, NULL); // get current time
            long  tt = te.tv_sec*1000LL + te.tv_usec/1000; // calculate milliseconds
            printf("\n Receiving time : %li for thread %d \n",tt,j);
            
            //Calculating the time difference between request and response
           
            printf("\n *******The time difference is************* %li for thread %d \n",(tt-tt1),j++); 
            array [j]=tt-tt1;
        
            close(sockfd); 
            }
            
	}
 
     


} 

int main(int argc, char *argv[])

{


    int i; 

    pthread_t tid[1000000]; 
    
    //Creating array of thread for a  number of connections

    if (strcmp(argv[1],"TCP")==0 )
       {
    
               for (i = 0; i < 10000; i++) 
                   {
                         //Running an array of thread for a  number of connections for TCP
                         pthread_create(&tid[i], NULL, creating_thread_tcp, (void *)&tid[i]);
     
                   }  

      
        TCP_Latency();
      

 

       } 



    else if (strcmp(argv[1],"UDP")==0 )

       {
                  
                  
             
               for (i = 0; i < 1000; i++) 
                   {
                         //Running an array of thread for a  number of connections for UDP
                         pthread_create(&tid[i], NULL, creating_thread_udp, (void *)&tid[i]);
     
                   }  

      
        UDP_Latency();
      

 

        } 

	pthread_exit(NULL);
	return 0;

}
