#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <time.h> 
#include <pthread.h> 
#include <stdio.h>
#include <sys/time.h>

#define TIME_OUT 10



int j=0;
int s=0;
int q=0;
long array [100000];
int mn;
int pq=0;
long fault_con [100000];
FILE *fp;
FILE *fp1;

//Calculates response failure for anumber of connections

void connection_failure()
{
                    int i; 
                    for (i = 1; i <= mn; i++) 
                           {
        
                    
                             printf("Response %li for thread %d\n",fault_con [i],i); 
                             fprintf(fp,"%d %li \n",i,fault_con [i]); // Writes the connection number and its response time (which is later used to test whether there was a succesful response or not)
     
        
                           } 

                       int remaining;
                       remaining = 10000-mn; 
                         for (i = 1; i <= remaining; i++) 
                           {
        
                     
                             fault_con [++mn]=-1;
                             fprintf(fp,"%d %d \n",mn,-1);
     
        
                           } 
                             int fault_counting = 0;
                             int success_con;
                             
                         for (i = 1; i <= 10000; i++) 
                           {
        
                                if(fault_con [i] ==-1)
                                   {
                                      fault_counting++;  // calculates the number of unsuccesful response
                                     
                                         if((i%1000)==0)
                                           {
                                              
                                             success_con=i-fault_counting;  // calculates the number of succesful response
                                             fprintf(fp1,"%d %d \n",i,success_con);
                                           } 
                                   } 
     
        
                           } 
                           

} 


void *creating_thread_udp(void *vargp) 
{ 
        mn=++pq;      
        char protocal[4] ="UDP";
        char URL[]="www.cs585.com";
        printf("The protocal is: %s\n",protocal);
        printf("The URL is: %s\n", URL);
		



        
	//connect to the address of the web Server
	char *address;
        
	address="127.0.0.1";//this IP address needs to get changed according to the network


	

	

	if(strcmp(protocal,"UDP")==0)
          {
	    
              
	    
          
            printf("UDP part\n");

            int sockfd; 
	    char buffer[1024]; 
	    char *hello = "Hello from client"; 
	    struct sockaddr_in     servaddr; 
	    char *address;
	    address="127.0.0.1"; //this IP address needs to get changed according to the network
	  
	    

	    if ( (sockfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0 ) 
            { 
                 if(q==0)
                   {
 
                       q++;
                       connection_failure();   

                       perror("socket creation failed"); 
	               exit(EXIT_FAILURE); 

                   }
                  
               
      
	        
	    } 
	  
	    memset(&servaddr, 0, sizeof(servaddr)); 
	      
	    // Filling server information 
	    servaddr.sin_family = AF_INET; 
	    servaddr.sin_port = htons(8080); 
	    //servaddr.sin_addr.s_addr = INADDR_ANY; 
	    inet_pton(AF_INET, address, &servaddr.sin_addr.s_addr);
	      
	    int n, len; 
            
            //calculates the request time of a connection
            struct timeval te1; 
            gettimeofday(&te1, NULL); // get current time
            long  tt1 = te1.tv_sec*1000LL + te1.tv_usec/1000; // calculate milliseconds
            printf("\n Sending time : %li for thread %d \n",tt1,j);
	        if(s==0)
                   {
 
                      s++;
                      sendto(sockfd, (const char *)hello, strlen(hello), 
	              MSG_CONFIRM, (const struct sockaddr *) &servaddr, sizeof(servaddr)); 
	              printf("Trying to make connection with server.\n"); 
            

                   }

               else
                   {
	    sendto(sockfd, (const char *)hello, strlen(hello), 
	    MSG_CONFIRM, (const struct sockaddr *) &servaddr, sizeof(servaddr)); 
	    printf("Trying to make connection with server.\n"); 

     

            n = recvfrom(sockfd, (char *)buffer, 1024,  
	    MSG_WAITALL, (struct sockaddr *) &servaddr, &len); 
	    buffer[n] = '\0'; 
	    printf("Server response: %s\n", buffer); 
	  
	   



               

            //calculates the response time of a connection
            struct timeval te; 
            gettimeofday(&te, NULL); // get current time
            long  tt = te.tv_sec*1000LL + te.tv_usec/1000; // calculate milliseconds
            printf("\n Receiving time : %li for thread %d \n",tt,j);
           

             fault_con [mn] = tt;

            //calculates the latency of a connection
            printf("\n *******The time difference is************* %li for thread %d \n",(tt-tt1),j++); 
            array [j]=tt-tt1;
        
            close(sockfd); 
            }
            
	}
 
     


} 

int main()

{


      fp=fopen("text1.txt","w"); // File which Writes the connection number and its response time (which is later used to test whether there was a succesful response or not)
      fp1=fopen("text2.txt","w"); // File which writes the number of trial and the number of succesful response for each trial
    
      int i; 
        for (i = 0; i < 10000; i++) 
      {
        
        fault_con [i] =-1;
       
        
     
        
      } 

    pthread_t tid[1000000]; 
  
    // creating an array of thread for a number of coonnections
    for (i = 0; i < 10000; i++) 
      {
        
        pthread_create(&tid[i], NULL, creating_thread_udp, (void *)&tid[i]);
       
        
     
        
      }  


     

      while(1)
       
       {
            if (j== 9999 )//
               {
                   for (i = 0; i < 10000; i++) 
                     {
                         printf("@@@@@@@@We are at number %d @@@@@@@@ %li \n",i+1,array [i+1]);
                         
                     } 
                   break;
               } 
       } 

      
     
      
   
                   
    
    

       

    pthread_exit(NULL);



	
	return 0;

}
