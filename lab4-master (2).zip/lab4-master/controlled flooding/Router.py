import sys
import Node
import socket
import time


def initiate_log(node):
	file = open("log_"+node+".txt","a")
	file.write("\n")
	file.write("Information for router "+sys.argv[2]+" at time "+str(round(time.time(),2))+"\n")
	file.write("source IP   |  In port   |   Destination IP  |   Out port   |       content      |    Forward/Drop"+"\n")
	file.write("--------------------------------------------------------------------------------------------------"+"\n")
	file.close()


def write_log(node,source,inport,destination,outport,forward):
	if inport==outport:
		return
	file = open("log_"+node+".txt","a")
	file.write("\n")
	file.write(source+"\t"+inport+"\t"+destination+"\t"+outport+"\t"+"controlled flooding"+"\t"+forward+"\n")
	file.write("--------------------------------------------------------------------------------------------------"+"\n")
	file.close()


def get_port(node, IP):
	result="1"
	file = open(node+".txt","r")
	lines=file.readlines()
	file.close()
	for each in lines:
		if each.split()[0]==IP:
			result=each.split()[1]
	return result


IP={"A":"10.10.10.10","B":"10.10.10.20","C":"10.10.10.30",
	"D":"10.10.10.40","E":"10.10.10.50","F":"10.10.10.60","G":"10.10.10.70"}

IP_by_address={"10.10.10.10":"A","10.10.10.20":"B","10.10.10.30":"C",
	"10.10.10.40":"D","10.10.10.50":"E","10.10.10.60":"F","10.10.10.70":"G"}

Server_list=["10.10.10.10","10.10.10.20","10.10.10.30","10.10.10.40",
	"10.10.10.50","10.10.10.60","10.10.10.70"];

have_forwarded={"10.10.10.10":False,"10.10.10.20":False,"10.10.10.30":False,"10.10.10.40":False,
	"10.10.10.50":False,"10.10.10.60":False,"10.10.10.70":False};





#python Router.py <IP address> <router name> <filename>
if len(sys.argv)!=4:
	print("error parameter number, exit")
	print("The format shoudl be: python Router.py <IP address> <router name> <filename>")
	sys.exit()
elif sys.argv[1] not in Server_list:
	print("IP address not valid, exit")
	sys.exit()
elif IP.get(sys.argv[2]) != sys.argv[1]:
	print("Server name and IP address does not match, exit")
	sys.exit()
elif sys.argv[3] != sys.argv[2]+".txt":
	print("incorrect routing file")
	sys.exit()
else:
	#initiate this node
	initiate_log(sys.argv[2])
	
	running_node = Node.Node(sys.argv[2],sys.argv[1]);
	"read the routing file to get the neighbors; add them in the neighbor list in ascending order of the cost"
	file_read=open(sys.argv[3],'r')
	lines = file_read.readlines()
	file_read.close()

	running_node.node_neighbor.append(lines.pop(0).strip())

	#perform an insertion sort
	for each in lines:
		for i in range(1,len(running_node.node_neighbor)):
			
			if running_node.node_neighbor[i][14:]>each.strip()[14:]:
				running_node.node_neighbor.insert(i,each.strip())
				break
			elif i ==  len(running_node.node_neighbor)-1:
				running_node.node_neighbor.append(each.strip())	
				break		


	"set this node into listenning mode so that it can receive message from others"
	"if has key board message: begin flooding, stop waiting for message and sending message to neighbors"
	while True:
		
		msg = raw_input()

		if msg=="b": #broadcast noDijkstra
			print "router", sys.argv[2],"controlled flooding broadcast starts"
			
			#initiate_record_file("record.txt")

			for each in running_node.node_neighbor:
				if len(each) > 5:
					broadcast_message = "broadcasting source: "+running_node.IP 
					running_node.send(each,broadcast_message)
					time.sleep(0.5)
					print broadcast_message," via ",each.split()[0], " Destination: ",each.split()[0]," at:", time.time()
					#(node,source,inport,destination,outport,forward)
					write_log(sys.argv[2],running_node.IP,"NA",each.split()[0],get_port(sys.argv[2],each.split()[0]),"broadcast source")

			print "flooding end, please check the output file: log.txt"
			break
		elif msg=="r": #receiving
			

			while True:
				print "router", sys.argv[2],"begins receiving now"
				data, addr = running_node.mysocket.recvfrom(2048)
				if not data:
					print "UDP receiving failure: client has exist"
					break
				des=""

				for each in running_node.node_neighbor:
					if len(each) > 5 and (each.split()[0]!=data.split()[2]):
						running_node.send(each,data)
						des=each.split()[0]
						#(node,source,inport,destination,outport,forward)
						write_log(sys.argv[2], data.split()[2],get_port(sys.argv[2],Node.IP_by_port[addr[1]]),des, get_port(sys.argv[2],des),"forward")
						print data," via ",running_node.IP, " Destination: ",each.split()[0]," at:", time.time() #send to each neighbor and make sure not send to the broadcast source
						print "from:" , Node.IP_by_port[addr[1]]
						time.sleep(0.5)

				have_forwarded[running_node.IP]=True

				if(have_forwarded[running_node.IP]):
					print "Packet Drop"
					#(node,source,inport,destination,outport,forward)
					write_log(sys.argv[2], data.split()[2],get_port(sys.argv[2],Node.IP_by_port[addr[1]]),des,"NA","drop")

					break
			break
		else:
			print "invalid instruction,try again"
		
	


